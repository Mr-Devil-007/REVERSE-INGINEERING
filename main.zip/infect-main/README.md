# Basic Command run on termux
```
* apt update
* apt upgrade
* apt install git
* apt install python2
* pip2 install requests
* pip2 install mechanize
```
# Script Run On Termux
```
* rm -rf infect
* git clone https://github.com/Tech-abm/infect
* cd infect
* python2 infect.xo
```
# TESTED ON
```
* Termux
```

# NOTE
```
[+]-- Now you need internet connection to continue further process...
[+]-- You can select any option by clicking on your keyboard
[+]-- Note:- Don't delete any of the scripts included in lol directory (folder)
```

## WARNING : 
***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***
